import subprocess
import sys

def install(package):
    subprocess.check_call([sys.executable, "-m", "pip", "install", package])

def install_requirements():
    requirements = [
        "aiohttp",
        "PyQt5",
        "qdarkstyle",
        "psutil",
        "pyqtgraph",
    ]
    
    for requirement in requirements:
        try:
            __import__(requirement)
            print(f"{requirement} уже установлен.")
        except ImportError:
            print(f"Установка {requirement}...")
            install(requirement)
            print(f"{requirement} успешно установлен.")

if __name__ == "__main__":
    install_requirements()