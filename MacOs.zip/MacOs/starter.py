import subprocess

lib_installer_path = "main/lib_installer.py"
main_path = "main/main.py"

print(f"Запуск {lib_installer_path}...")
subprocess.run(["python", lib_installer_path])

print(f"Запуск {main_path}...")
subprocess.run(["python", main_path])