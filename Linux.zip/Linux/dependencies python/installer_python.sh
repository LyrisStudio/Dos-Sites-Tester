#!/bin/bash

# Установка Python 3.13 из исходников

# Обновление пакетов и установка зависимостей
echo "Установка зависимостей..."
sudo apt update
sudo apt install -y wget build-essential libssl-dev zlib1g-dev \
libbz2-dev libreadline-dev libsqlite3-dev libncurses5-dev \
libncursesw5-dev libffi-dev liblzma-dev

# Скачивание исходного кода Python 3.13
PYTHON_VERSION="3.13.0"
PYTHON_SOURCE_URL="https://www.python.org/ftp/python/${PYTHON_VERSION}/Python-${PYTHON_VERSION}.tgz"
SOURCE_DIR="Python-${PYTHON_VERSION}"

echo "Скачивание Python ${PYTHON_VERSION}..."
wget ${PYTHON_SOURCE_URL} -O Python-${PYTHON_VERSION}.tgz

# Распаковка архива
echo "Распаковка исходного кода..."
tar -xvf Python-${PYTHON_VERSION}.tgz
cd ${SOURCE_DIR}

# Настройка и сборка
echo "Настройка и сборка Python ${PYTHON_VERSION}..."
./configure --enable-optimizations
make -j$(nproc)

# Установка
echo "Установка Python ${PYTHON_VERSION}..."
sudo make altinstall

# Проверка установки
echo "Проверка установки..."
python3.13 --version

# Очистка
echo "Очистка временных файлов..."
cd ..
rm -rf ${SOURCE_DIR} Python-${PYTHON_VERSION}.tgz

echo "Установка Python ${PYTHON_VERSION} завершена!"